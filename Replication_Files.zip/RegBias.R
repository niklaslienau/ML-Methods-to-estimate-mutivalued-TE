#this script runs simulations to demonstrate regularization bias
# The resulting plot can be found in Figure 2 of the text doc

library(glmnet)
library(tidyverse)
library(reshape2)
library(ggplot2)


k=200 # iterations
res = matrix(rep(0, k*3), nrow = k) #save results for the three estimators



for(i in 1:k){
  
  n <- 100 
  p <- 100
  beta2 <- c(1, 0.5, rep(0,p-2))
  gamma <- c(0.5, 1, rep(0,p-2))
  beta1 <- 0.5
  beta1hat <- rep(NA, 3)
  
  
  # -----------draw data
  
  X <- matrix(rnorm(n*p), n, p) #Covariates
  W <- X%*%gamma + rnorm(n)/2 #Treatment
  Y <- beta1*W + X%*%beta2 + rnorm(n)
  M <- cbind(W,X) #matrix of treatment and covariates
  
  
  
  
  # ------ (1) normal LASSO with CV penalty parameter
  
  fit.lasso.upen <- cv.glmnet(M, Y, penalty.factor=c(0,rep(1,p)))
  beta1hat[1] <- coef(fit.lasso.upen, s = "lambda.min")[2] 
  
  
  
  
  # ------ (2) post-LASSO
  
  # select variables with cross-validated LASSO 
  ind_sel <- as.logical(coef(fit.lasso.upen, s = "lambda.min")[-1] != 0)
  M.sel <- M[,ind_sel]
  
  # OLS on selected variables
  fit.plasso <- lm(Y~M.sel)
  beta1hat[2] <- coef(fit.plasso)[2]
  
  
  # ------ (3) Double LASSO     
  
  # partial out X from Y
  fit.lasso.Y <- cv.glmnet(X, Y)
  fitted.lasso.Y <- predict(fit.lasso.Y, newx=X, s="lambda.min")
  Ytilde <- Y - fitted.lasso.Y
  
  # partial out X from W
  fit.lasso.W <- cv.glmnet(X, W)
  fitted.lasso.W <- predict(fit.lasso.W, newx=X, s="lambda.min")
  Wtilde <- W - fitted.lasso.W
  
  # run OLS of Ytilde on Wtilde
  fit.doubleLASSO <- lm(Ytilde ~ Wtilde)
  beta1hat[3] <- coef(fit.doubleLASSO)[2]
  
  
  #save results 
  res[i,] = beta1hat
}

### column names 
colnames(res) <- c( "LASSO", "Post-LASSO", "double LASSO")


#reshape data for gg plot
data_plot = as.data.frame(res)
data_plot = data_plot %>% gather(key = "column_name", value = "value")

#plot
ggplot(data_plot, aes(x = value, fill = column_name)) +
  geom_density(alpha = 0.5) +
  labs(x = "estimate of target parameter", y = "Density") +
  scale_fill_discrete(name = "Estimators") +
  geom_vline(xintercept = 0.5, color = "black", linetype = "dashed", size = 1)
  

