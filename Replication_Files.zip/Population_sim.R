####################
#This code calculates the true nu, namely the true potential outcome means conditional on each treatment group in the population

#Note: Because its to difficult to solve for this algebraically, we will draw a huge sample and treat it as the true population
# since n = 1e6 is large enough -> treat this as if this is the true population

library(nnet)
library(trust)
library(Rcpp)
library(MASS)
library(mvtnorm)



#---------------------------------(1) Define Functions-------------------------

# compute X.dagger, which standardizes W defined in Xu and Tan (2022), Section 6. (page 29)

X.dagger <- function(X){
  W <- capply(X)
  mt0 <- 1 - pnorm(-1)
  mt1 <- dnorm(-1)
  mt2 <- -(2 * pnorm(-1) -1 )/2 - dnorm(-1) + 1/2
  mt3 <- 3 * dnorm(-1)
  mt4 <- -3/2 * (2 * pnorm(-1) - 1) - 4 * dnorm(-1) + 3/2
  m.x1 <- mt0 + 2 * mt1 + mt2
  v.x1 <- mt0 + 4 * mt1 + 6 * mt2 + 4 * mt3 + mt4
  v.x1 <- v.x1 + 1 + 2 * (mt1 + 2 * mt2 + mt3)
  out <- (W - m.x1) / sqrt(v.x1)
  return(out)
}


# cpp function imitating R function apply(X, c(1, 2), function(x)) to make program faster 

cppFunction('NumericMatrix capply(NumericMatrix X){
int nr = X.nrow();
int nc = X.ncol();
NumericMatrix out(nr, nc);
for(int i = 0; i < nr; i++){
  for(int j = 0; j < nc; j++){
    if(X(i, j) > -1){
      out(i, j) = X(i, j) + (X(i, j) + 1) * (X(i, j) + 1);
    }else{
      out(i, j) = X(i, j);
    } }
}
return out;
}')

#----------------------------(2) Set coefficients ------------------------------
n <- 1000; p <- 50; case.ps <- 0; case.or <- 0; K <- 4
inters.ps <- rep(0, K)
gammas <- matrix(0, p, K)
coef <- cbind(c(1.0, -0.5, -0.25, 0.125), c(-0.5, -0.25, 0.125, 1.0),
              c(-0.25, 0.125, 1.0, -0.5))
for(t_ in 2:K){
  gammas[1:4, t_] <- coef[, t_ - 1]
}

# true coefficients in OR model
inters.or <- 0:(K-1)
coef.alpha <- c(1.0, -1.0, -1.0, 1.0)
alphas <- matrix(0, p, K)
alphas[c(1, 5, 6, 7), 1] <- coef.alpha
alphas[c(2, 7, 8, 9), 2] <- coef.alpha
alphas[c(3, 9, 10, 11), 3] <- coef.alpha
alphas[c(4, 11, 12, 13), 4] <- coef.alpha

# variance-covariance matrix of covariates
Sigma <- matrix(0, p, p)
for(j in 1:p){
  Sigma[j, ] <- 0.5^{abs(j - 1:p)}
}

# covariates for calculating true mu and nu, take X.all as population
# since n = 1e6 is large enough
X.all <- rmvnorm(1e6, mean=rep(0, p), sigma=Sigma)
X.all.dag <- X.dagger(X.all)








#--------------------------- (3) Sim Data and calc true MU's-------------------------------
if(case.ps == 1){
  eta.gamma.all <- exp(X.all%*%gammas) # X times the coefficients (gamma)
}else{
  eta.gamma.all <- exp(X.all.dag%*%gammas) # with standardized X
}

eta.gamma.all.sum <- rowSums(eta.gamma.all)
P.all <- eta.gamma.all / eta.gamma.all.sum # output of final multi class logit on population level
EP <- colMeans(P.all) # P(T = t) ,prob per treatment level in population
R.all <- apply(P.all, 1, function(x) drop(rmultinom(n=1, size=1, prob=x))) # draw from population prob to assign to treatment group
R.all <- t(R.all) #transpose to get into (NxK)

rm(eta.gamma.all); rm(eta.gamma.all.sum) # remove population coefficients from environment

#Outcome Model
if(case.or == 1){
  eta.alpha.all <- X.all%*%alphas #cbind(1, X.all)
}else{
  eta.alpha.all <- X.all.dag%*%alphas #cbind(1, X.all.dag)
}

# calculate true nu (potential outcome for every treatment group)
nu <- matrix(NA, K, K)
tau <- matrix(NA, K, K)

eta.alpha.all <- eta.alpha.all+matrix(rep(t(inters.or),each=1e6),nrow=1e6) # add treatment effects in population

for(t_ in 1:K){
  tau[, t_] <- colMeans(R.all * eta.alpha.all[, t_])
  nu[, t_] <-  tau[, t_] / EP
}
nu = t(nu) #have to take transpose to bring it in "correct " format
#nu format: cols = Treatment Group ; rows = Potential Outcome for each treatment level

#remove all objects we dont want in environment
rm(eta.alpha.all); rm(P.all) ; rm(R.all) ; rm(tau) ; rm(X.all) ; rm(X.all.dag)