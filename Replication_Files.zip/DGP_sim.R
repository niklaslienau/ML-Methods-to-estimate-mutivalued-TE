# Set wd to folder where this script is stored!



#--------------------(0) Goal of Script ----------
# GOAL OF THIS SCRIPT : Define DGP in one function.
#This function can then be called in each iteration of the monte carlo simulation
#Arguments: n= Sample Size 
#Output : A list element called simu.data
#--------------------(1) Define Functions & Population values ------------------------
#Run another script to define functions and calculate the true potential outcome means in the population 
script_to_run = "Population_sim.R"
source(script_to_run)

#--------------------(2) Define the data generating function ------------------------

simu_dat = function(n){

n <- n; p <- 50; case.ps <- 1; case.or <- 1; K <- 4 
#case.ps and case.os indicate wether ps or os models are correctly specified 
#if not we use standardized covs


#----------------------
# Draw Covariate Matrix
X <- rmvnorm(n, mean=rep(0, p), sigma=Sigma)
X.dag <- X.dagger(X) #standardize

#---------------------
#Treatment Assignment

# Obtain R based on simulated P
if(case.ps == 1){
  eta.gamma <- exp(X%*%gammas)
}else{
  eta.gamma <- exp(X.dag%*%gammas)
}

eta.gamma.sum <- rowSums(eta.gamma)
P <- eta.gamma / eta.gamma.sum # logistic regression output
R <- apply(P, 1, function(x) drop(rmultinom(n=1, size=1, prob=x))) # assign treatment based on probabilities
R <- t(R) #transpose
id <- apply(R, 2, function(x) which(x == 1)) #list of 4 elements: who got treatment level 1, 2, 3,4
rm(eta.gamma); rm(eta.gamma.sum); rm(P)

#---------------------
# Outcome Model
if(case.or == 1){
  eta.alpha <- X%*%alphas 
}else{
  eta.alpha <- X.dag%*%alphas 
}
eta.alpha <- eta.alpha+matrix(rep(t(inters.or),each=n),nrow=n) #add treatment effect 

# generate simulated y
y <- rep(NA, n)
for(t_ in 1:K){
    y[id[[t_]]] <- drop(cbind( eta.alpha[id[[t_]],t_]))  #for t=1 , from eta alpha, take all that actually received 1, and take their column 1 value
   }
y <- y + rnorm(n, mean=0, sd=1) #add random error



#############################################
# list to save results of simulated data
# X covariate Matrix
# R Treatment Assignment Matrix
# y outcome vector
# mu.gaus true potential outcome means
# nu.gaus true potential outcome means conditional on treatment group
# gammas = True coef in Propensity Model
# alphas = True coef in Outcome Model
##########################################

simu.data <- list(X=X, R=R,
                  inters.ps=inters.ps, gammas=gammas,
                  inters.or=inters.or, alphas=alphas,
                  y.gaus=y, mu=inters.or, nu=nu,
                  case.ps=ifelse(case.ps == 0, "misspecified", "correctly specified"),
                  case.or=ifelse(case.or == 0, "misspecified", "correctly specified"))

return(simu.data)
}


