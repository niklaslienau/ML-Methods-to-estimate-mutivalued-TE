#Start------------------------------------------------------------------------------------------
## Load Packages, Input Functions defined in other scripts..

#Packages
library(gbm)
library("xgboost")
library(glmnet)

#set seed to allow for replication
set.seed(123)

#set wd to correct folder
path = "/Users/niklaslienau/Desktop/Uni/Thesis" 
setwd(path)

#This script calls another file that defines the DGP and loads the true potential outcome means in the population
script_to_run = "DGP_sim.R"
source(script_to_run)

#Data Simulation-------------------------------------------------------------------------------------------------------------------
##Generate the Data
k = 2 #number of iterations in MC

#Create Empty Matrices to save estimates in each iteration
#rows are iterations and columns are mus for each potential outcome
MC_mu_rs_lm = matrix(rep(0,k*4), nrow=k)
MC_mu_rs_lasso = matrix(rep(0,k*4), nrow=k)
MC_mu_ipw_mlr = matrix(rep(0,k*4), nrow=k)
MC_mu_ipw_gbt = matrix(rep(0,k*4), nrow=k)
MC_mu_aipw_lm_mlr = matrix(rep(0,k*4), nrow=k)
MC_mu_aipw_lm_gbt = matrix(rep(0,k*4), nrow=k)
MC_mu_aipw_lasso_mlr = matrix(rep(0,k*4), nrow=k)
MC_mu_aipw_lasso_gbt = matrix(rep(0,k*4), nrow=k)


#!!! loop starts here !!!

for(j in 1:k){ 
  dat = simu_dat(n=1000)
  
  
  
  #Propensity Models------------------------------------------------------------------------------------------------------------------
  
  
  ###Multionomial Log Regression with Regularization and CV
  
  ps_mlr_fit = cv.glmnet(dat$X, dat$R, family= "multinomial" , type.multinomial = "ungrouped") #fit model 
  #plot(ps_mlr_fit) #plot CV graph
  mlr_ps= predict(ps_mlr_fit,dat$X,s="lambda.min" ,type= "response" ) #predict propensity scores at optimal lambda
  mlr_ps = mlr_ps[,,1]
  ####Gradient Boosted Trees
  
  #need factor variable for treatment class -> matrix with 4 columns to vector with treatment group for each individual
  empty_matrix= matrix(data= rep(0,1000*4), ncol = 4 , nrow=1000) # create empty matrix
  for(i in 1:ncol(dat$R)){ 
    empty_matrix[,i]=dat$R[,i]*i
  }
  treat_factor= apply(empty_matrix,1,function(x) sum(x)) # vector with treatment group for each individual 
  rm(empty_matrix) # remove matrix
  
  #now fit GBT Classifier
  
  
  ps_gbt_fit= gbm(treat_factor~dat$X, distribution = "multinomial", n.trees = 250)
  gbt_ps=as.data.frame(predict(ps_gbt_fit, newdata = as.data.frame(dat$X), type= "response", n.trees = 250))
  
  
  
  
  
  
  #Outcome Models
  
  
  #Outcome Models (1)------------------------------------------------------------------------------------------------
  #Prepare Data for LM , has to be one big dataframe for predict() function with lm object
  x_names = c()
  for (i in 1:50) {
    x_names <- c(x_names, paste0("X", i))
  }
  
  colnames= c("y", x_names)
  data_lm= as.data.frame(cbind(dat$y.gaus,dat$X))
  colnames(data_lm)= colnames
  
  #Outcome Models (2) ----------------------------------------------------------------------------------------------------------------
  ##Fit RA Models with LM(1) and LASSO(2)
  
  
  ### Basic Linear Reg Model (1)
  
  rs_lm = list() #empty list to save all model
  for(i in 1:4){
    units = which(dat$R[,i]==1) #run model for each treatment group separately
    rs_lm[[i]] <- lm(y~., data = data_lm[units,])
    assign(paste0("reg",i), rs_lm[[i]]) #assign name with treatment group
  }
  
  
  
  ### Lasso Reg Model (2)
  rs_lasso = list() #empty list to save all models
  for(i in 1:4){
    units = which(dat$R[,i]==1) #run model for each treatment group separately
    cv_model = cv.glmnet( x= dat$X[units,], y=dat$y.gaus[units], alpha=1  ) #lasso with CV 
    best_lambda = cv_model$lambda.min #choose best lambda 
    rs_lasso[[i]] = glmnet(x= dat$X[units,], y=dat$y.gaus[units], alpha=1, lambda = best_lambda) #fit model with optimal shrinkage
    assign(paste0("lasso_reg", i), rs_lasso[[i]]) #assign name with treatment group
  }
  
  
  
  #Potential Outcome Mean Estimators-------------------------------------
  ##Estimate the Potential Outcome means with RA(1), IPW(2) and AIPW(3)
  
  #Regression Adjustment (1)
  mu_rs_lm= rep(0,4) #linear model
  for (i  in 1:4) {
    mu_rs_lm[i]  = mean(predict(rs_lm[[i]], data_lm))
  }
  
  mu_rs_lasso=rep(0,4) #lasso model
  for(i in 1:4){
    mu_rs_lasso[i]= mean(predict(rs_lasso[[i]], newx= dat$X))
  }
  
  
  
  
  ### IPW (2)
  mu_ipw_mlr= rep(0,4)#multinomial logistic regression
  for(i in 1:4){
    mu_ipw_mlr[i] =mean((dat$R[,i]*dat$y.gaus)/mlr_ps[,i])
  }
  
  mu_ipw_gbt= rep(0,4) #gradient boosted tree
  for(i in 1:4){
    mu_ipw_gbt[i] = mean((dat$R[,i]*dat$y.gaus)/gbt_ps[,i])
  }
  
  
  
  ### AIPW (3)
  
  #response model : linear regression
  mu_aipw_lm_mlr = rep(0,4) #linear reg and logisitc reg (1)
  for(i in 1:4){
    mu_aipw_lm_mlr[i] =mean(((dat$R[,i]*dat$y.gaus)/mlr_ps[,i]) - ((dat$R[,i]-mlr_ps[,i])/mlr_ps[,i])*predict(rs_lm[[i]], data_lm))
  }
  
  mu_aipw_lm_gbt = rep(0,4) #linear reg and gradient boosted trees (2)
  for(i in 1:4){
    mu_aipw_lm_gbt[i] =mean(((dat$R[,i]*dat$y.gaus)/gbt_ps[,i]) - ((dat$R[,i]-gbt_ps[,i])/gbt_ps[,i])*predict(rs_lm[[i]], data_lm))
  }
  
  #response model :lasso regression
  
  mu_aipw_lasso_mlr = rep(0,4) #lasso reg and logistic reg (3)
  for(i in 1:4){
    mu_aipw_lasso_mlr[i] =mean(((dat$R[,i]*dat$y.gaus)/mlr_ps[,i]) - ((dat$R[,i]-mlr_ps[,i])/mlr_ps[,i])*predict(rs_lasso[[i]], newx= dat$X))
  }
  
  
  mu_aipw_lasso_gbt = rep(0,4) #lasso reg and gradient boosted trees (4)
  for(i in 1:4){
    mu_aipw_lasso_gbt[i] =mean(((dat$R[,i]*dat$y.gaus)/gbt_ps[,i]) - ((dat$R[,i]-gbt_ps[,i])/gbt_ps[,i])*predict(rs_lasso[[i]], newx= dat$X))
  }
  
  
  
  
  #Store Simulation Results----------------------------------
  ### Create Average Estimates and variance estimates over all iterations
  #Save everything in a list object
  
  MC_mu_rs_lm[j,] = mu_rs_lm
  MC_mu_rs_lasso[j,] = mu_rs_lasso
  MC_mu_ipw_mlr[j,] = mu_ipw_mlr
  MC_mu_ipw_gbt[j,] = mu_ipw_gbt
  MC_mu_aipw_lm_mlr[j,] = mu_aipw_lm_mlr
  MC_mu_aipw_lm_gbt[j,] = mu_aipw_lm_gbt
  MC_mu_aipw_lasso_mlr[j,] = mu_aipw_lasso_mlr
  MC_mu_aipw_lasso_gbt[j,] = mu_aipw_lasso_gbt
  
  
  
}

# !!!! loop ends here !!!



#Store Results-------------------------------------------
#function to create estimators for mu and var(estimator) from all iterations
save_res =function(matrix){
  avg = apply(matrix,2,function(x) mean(x) )
  var = apply(matrix,2,function(x) var(x) )
  results = list(avg, var)
  names(results) = c("mu", "var_mu")
  return(results)
}

list_estimators = list(MC_mu_rs_lm, MC_mu_rs_lasso, MC_mu_ipw_mlr , MC_mu_ipw_gbt, MC_mu_aipw_lm_mlr, MC_mu_aipw_lm_gbt, MC_mu_aipw_lasso_mlr, MC_mu_aipw_lasso_gbt) #all estiamtes
results = lapply(list_estimators, save_res) #save results in one final list
#add names of estimators in final list
estimator_names= sapply(substitute(list(MC_mu_rs_lm, MC_mu_rs_lasso, MC_mu_ipw_mlr , MC_mu_ipw_gbt, MC_mu_aipw_lm_mlr, MC_mu_aipw_lm_gbt, MC_mu_aipw_lasso_mlr, MC_mu_aipw_lasso_gbt)), deparse)[-1]
names(results)= estimator_names



#Get data frames with results for 
#(1) Mean Estimate
res_estimates =as.data.frame(sapply(results, function(x) x$mu))
row.names(res_estimates) = c("mu_1", "mu_2", "mu_3", "mu_4") #rownames
#(2) Variance for each estimator
res_variance = as.data.frame(sapply(results, function(x) x$var_mu))
row.names(res_variance) = c("mu_1", "mu_2", "mu_3", "mu_4") #rownames




#(3) bias for each estimator
true_mus <- matrix(rep(inters.or, times = 8), ncol = 8, byrow = FALSE) #true
bias = res_estimates-true_mus #bias for each estimator
abs_bias = abs(bias) #absolut bias for each estimator

#take transposes
res_estimates = t(res_estimates)
res_variance = t(res_variance)
res_bias = t(bias)
res_absbias = t(abs_bias)





#Average Bias and Variance across all 4 potential outcomes

summary =t(as.data.frame(rbind(apply(res_absbias,1, function(x) mean(x)),apply(res_variance,1, function(x) mean(x)) )))
colnames(summary)=c("Absolut Bias","Variance")
summary = round(summary, 4)

#LATEX TABLE CODE for Summary!
library(xtable)
tex_table= xtable(summary, digits = c(0,4,4))
print.xtable(tex_table, type= "latex")
print(summary)

